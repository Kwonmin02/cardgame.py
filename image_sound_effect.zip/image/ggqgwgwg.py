import pygame, sys, random

BLACK = (0, 0, 0)
SCALE_FACTOR = 1.4

pygame.init()
screen = pygame.display.set_mode((int(2240 / SCALE_FACTOR), int(1260 / SCALE_FACTOR)))
clock = pygame.time.Clock()

def resize_image(image_path, scale_factor):
    """
    이미지를 비율로 크기 조절하는 함수
    
    :param image_path: 원본 이미지 경로
    :param scale_factor: 크기 조절 비율
    :return: 크기 조절된 이미지
    """
    image = pygame.image.load(image_path)
    new_size = (int(image.get_width() / scale_factor), int(image.get_height() / scale_factor))
    return pygame.transform.scale(image, new_size)

def adjust_position(position, scale_factor):
    """
    위치 값을 비율로 조정하는 함수
    
    :param position: 원본 위치 값 (x, y)
    :param scale_factor: 위치 조정 비율
    :return: 조정된 위치 값
    """
    return (int(position[0] / scale_factor), int(position[1] / scale_factor))

map1 = [
    (resize_image("image/map/sp1/0.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/1.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/2.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/3.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/4.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/5.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/6.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/7.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/8.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/9.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp1/10.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
]
map2 = [
    (resize_image("image/map/sp2/0.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/1.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/2.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/3.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/4.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/5.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/6.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/7.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/8.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/9.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
    (resize_image("image/map/sp2/10.png", SCALE_FACTOR), adjust_position((0, 0), SCALE_FACTOR)),
]
x = 0

class button():
    def __init__(self, img, pos):
        self.image = resize_image(img, SCALE_FACTOR)  # 버튼 이미지 크기 조절
        self.x_pos = pos[0]
        self.y_pos = pos[1]
        self.rect = self.image.get_rect(topleft = adjust_position((self.x_pos, self.y_pos), SCALE_FACTOR))

    def update(self):
        screen.blit(self.image, self.rect)

    def checkmouse(self, position):
        if position[0] in range(self.rect.left, self.rect.right) and position[1] in range(self.rect.top, self.rect.bottom):
            return True
        else: return False

    def button_change(self, position, img):
        if position[0] in range(self.rect.left, self.rect.right) and position[1] in range(self.rect.top, self.rect.bottom):
            self.image = resize_image(img, SCALE_FACTOR)  # 버튼 이미지 크기 조절
            self.rect = self.image.get_rect(topleft = adjust_position((self.x_pos, self.y_pos), SCALE_FACTOR))
            screen.blit(self.image, self.rect)
            pygame.display.update()

# 게임 시작시 나오는 메뉴 화면
def menu():
    pygame.display.set_caption("MENU")
    tmr = 0


    bg_img = [resize_image("image/main/main1.png", SCALE_FACTOR), resize_image("image/main/main2.png", SCALE_FACTOR)] 
    p1_default = resize_image("image/main/p1_1.png", SCALE_FACTOR) 
    p1_change = resize_image("image/main/p1_2.png", SCALE_FACTOR) 
    p2_default = resize_image("image/main/p2_1.png", SCALE_FACTOR) 
    p2_change = resize_image("image/main/p2_2.png",SCALE_FACTOR) 
    p1_current = p1_default
    p2_current = p2_default

    while True:
        tmr = tmr + 1
        global x

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        screen.blit(bg_img[0], (0, 0))

        MENU_MOUSE_POS = pygame.mouse.get_pos()
        MENU_MOUSE_PRESS = pygame.mouse.get_pressed()

        start = button("image/main/start1.png", adjust_position((266, 938), SCALE_FACTOR))
        exit = button("image/main/exit1.png", adjust_position((266, 1071), SCALE_FACTOR))
        P1 = button(p1_current, adjust_position((987, 868), SCALE_FACTOR))
        P2 = button(p2_current, adjust_position((1589, 868), SCALE_FACTOR))
        
        start.update()
        exit.update()
        P1.update()
        P2.update()

        # start
        if start.checkmouse(MENU_MOUSE_POS):
            start.button_change(MENU_MOUSE_POS, "image/main/start2.png")
            if MENU_MOUSE_PRESS[0]:
                main()
        else:
            start.button_change(MENU_MOUSE_POS, "image/main/start1.png")
        
        # exit
        if exit.checkmouse(MENU_MOUSE_POS):
            exit.button_change(MENU_MOUSE_POS, "image/main/exit2.png")
            if MENU_MOUSE_PRESS[0]:
                pygame.quit()
                sys.exit()
        else:
            exit.button_change(MENU_MOUSE_POS, "image/main/exit1.png")
        
        # P1
        if P1.checkmouse(MENU_MOUSE_POS):
            P1.button_change(MENU_MOUSE_POS, "image/main/p1_2.png") 
            if MENU_MOUSE_PRESS[0]:
                p1_current = p1_change
                p2_current = p2_default
                x = 1
        
        # P2
        if P2.checkmouse(MENU_MOUSE_POS):
            P2.button_change(MENU_MOUSE_POS, "image/main/p2_2.png")
            if MENU_MOUSE_PRESS[0]:
                p2_current = p2_change
                p1_current = p1_default
                x = 2

        if MENU_MOUSE_POS[0] in range(0, int(2240 / SCALE_FACTOR)) and MENU_MOUSE_POS[1] in range(0, int(1260 / SCALE_FACTOR)):
            screen.blit(bg_img[1], (0, 0))
            start.update()
            exit.update()
            P1.update()
            P2.update()

        pygame.display.update()
        clock.tick(10)

# 플레이 버튼 눌렀을 때 넘어갈 화면
def main():
    tmr = 0
    screen.fill(BLACK)
    global x
    
    while True:
        tmr = tmr + 1
        MENU_MOUSE_POS = pygame.mouse.get_pos()
        MENU_MOUSE_PRESS = pygame.mouse.get_pressed()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        if x == 1:
            if tmr < 11:
                screen.blit(map1[tmr % 11][0], map1[tmr % 11][1])
                
        elif x == 2:
            if tmr < 11:
                screen.blit(map2[tmr % 11][0], map2[tmr % 11][1])

        stand = button("image/map/stand1.png", adjust_position((170, 570), SCALE_FACTOR))
        stop = button("image/main/stop1.png", adjust_position((2211, 28), SCALE_FACTOR))

        stand.update()
        stop.update()

        # stage_click
        if stand.checkmouse(MENU_MOUSE_POS):
            stand.button_change(MENU_MOUSE_POS, "image/map/stand2.png")
            if MENU_MOUSE_PRESS[0]:
                stage1_1()
        else:
            stand.button_change(MENU_MOUSE_POS, "image/map/stand1.png")

        if stop.checkmouse(MENU_MOUSE_POS):
            pygame.draw.rect(screen, BLACK, stop.rect)
            stop.button_change(MENU_MOUSE_POS, "image/main/stop2.png")
            if MENU_MOUSE_PRESS[0]:
                option()
        else:
            stop.button_change(MENU_MOUSE_POS, "image/main/stop1.png")

        pygame.display.update()
        clock.tick(10)

# 스테이지 화면에서 톱니바퀴 누를때
def option():
    tmr = 0
    screen.fill(BLACK)

    while True:
        tmr = tmr + 1
        MENU_MOUSE_POS = pygame.mouse.get_pos()
        MENU_MOUSE_PRESS = pygame.mouse.get_pressed()
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        
        title = button("image/main/title1.png", adjust_position((800, 300), SCALE_FACTOR))
        exit = button("image/main/exit1.png", adjust_position((800, 600), SCALE_FACTOR))
        title.update()
        exit.update()

        if title.checkmouse(MENU_MOUSE_POS):
            title.button_change(MENU_MOUSE_POS, "image/main/title2.png")
            if MENU_MOUSE_PRESS[0]:
                menu()
        else:
            title.button_change(MENU_MOUSE_POS, "image/main/title1.png")

        if exit.checkmouse(MENU_MOUSE_POS):
            exit.button_change(MENU_MOUSE_POS, "image/main/exit2.png")
            if MENU_MOUSE_PRESS[0]:
                pygame.quit()
                sys.exit()
        else:
            exit.button_change(MENU_MOUSE_POS, "image/main/exit1.png")
        
        pygame.display.update()
        clock.tick(10)
        



  



if __name__ == '__main__':
    menu()
